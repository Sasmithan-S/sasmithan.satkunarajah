#include <libTableauNoir.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h> //Utile pour que le random se fasse dès le lancement du jeu
#include <math.h>
#define VITESSE_JOUEUR 4
#define AXEY 295
#define AXEX 400
#define temps_immune 3.0

typedef struct { double dx;double dy;} vecteur;
typedef struct {double x1;double y1;double x2;double y2;int taille;} coord_t;
typedef struct {coord_t position; int activé; int num; double countdown;Image image1;Image image2;} image_explosion;
typedef struct { int r; int v; int b;} couleur;
typedef struct { int immunité;double dt_immunité;coord_t position;int vie;Image image;Image image2;Image image3;Image image4;image_explosion explosion;int immunité_clignotement;double temps_clignotement;}
 perso;
typedef struct {  coord_t position;vecteur v;int boom;int nombre;Image image;} missile ;
typedef struct {coord_t position;coord_t position2;couleur couleur;} etoiles ;
typedef struct {  coord_t position; int activé;Image image;image_explosion explosion;} astéroide;
typedef struct {  coord_t position; double sens;int activé;int peu_tirer;double recharge; missile missile[20]; image_explosion explosion;int sens_image;Image image; } ennemis ;
typedef struct {int cpt;Image image[10];}compteur;
typedef struct {Image image;coord_t position;int activé;} image_jeu; 
typedef struct {  Image image[2]; int nbre_coeur;} coeur_r ;
typedef struct {  Image image_joueur;  perso joueur;  int joueur_mort;  int jeu_allumé; int manche;   ennemis ennemis[6];  astéroide astéroide[4] ;  missile  missile[20];  double recharge;  double groupe_ennemis;  double nbre_ennemis;  double countdown_ennemis;  double countdown_asté;  etoiles etoiles[40];   int animation_debut;  compteur compteur; image_jeu début ; image_jeu fin; Image ennemis2; Image ennemis1;  coeur_r coeur;  Son tir_joueur;  Son son_explosion;  Son son_explosion_astéroide;  Son son_impact; Son son_impact_joueur; Son son_fin; Son musique_menu; double countdown_tir_ennemis;} etat_t;

etat_t init_test();
void mise_a_jour(etat_t * e);
void  init_perso (etat_t  * e);
void init_coeur (etat_t * e);
void init_image_début_et_fin (etat_t * e);
void init_son(etat_t * e);
void charger_image_compteur(etat_t * e);
void init_missile(etat_t * e);
void init_astéroide(etat_t * e);
void init_ennemis(etat_t * e);
void init_image_explosion(etat_t * e);
void init_étoiles(etat_t * e);
void init_image_fin (etat_t * e);
void affichage (etat_t etat);
void afficher_compteur(etat_t etat);
void afficher_ennemis_et_missile (etat_t etat);
void afficher_astéroide (etat_t etat);
void afficher_missile(etat_t etat);
void afficher_coeur (etat_t etat);
void afficher_début_et_gameover(etat_t etat);
void afficher_étoiles(etat_t etat);
void afficher_perso (perso joueur);
void disparition_étoiles(etoiles * e);
void reinitialisation (etoiles * e, etat_t * etat) ;
void deplacement_étoiles(etoiles * etoiles, double dt, etat_t * e );
void mise_à_jour_joueur (etat_t * e, EtatSourisClavier esc, double dt);
void mort_joueur (etat_t * e);
void maj_immunité(perso * j, etat_t * e, double dt);
void activation_immunité(etat_t * e);
void deplacement_joueur(perso * e, EtatSourisClavier esc, double dt);
void deplacement_image_fin(image_jeu * fin, double dt);
void mise_à_jour_explosion(etat_t * e, double dt);
void animation_explosion(image_explosion * explosion, double dt);
int recherche_missile_actif (missile  missile[] );
void animation_explosion_astéroide(astéroide * astéroide);
void collision_joueur_ennemis (etat_t *  e);
void collision_missile_ennemis (etat_t * e, missile * missile);
void collision_joueur_astéroide(perso *  p, astéroide * astéroide, etat_t * e);
void collision_missile_astéroide(etat_t * e);	  
int collision (coord_t objet, coord_t objet2);
void groupe_de_5_ennemis(etat_t * e);
void apparition_astéroide( etat_t *  e, double dt);
void apparition_missile (etat_t * e, double dt);
void liste_ennemis_capables (etat_t * e, double dt);
void tir_ennemis (ennemis * ennemis, perso * joueur);
void sens_déplacement_ennemis(ennemis *  ennemis);
void champs_ennemis(etat_t * e, double dt);
void ecart_temps_ennemis(etat_t * e);
void déplacement_astéroide(astéroide * astéroide, double dt);
void déplacement_missile( missile * missile, double dt);
void deplacement_et_collision_missile_ennemis(etat_t * e);
void deplacement_vertical(coord_t * e);
double norme (vecteur u);
vecteur vect(coord_t A, coord_t B);
vecteur moyenne(coord_t a);
void touches_fin( etat_t * e,EtatSourisClavier esc);
int hazard(int min, int max);
int aléatoire (int max, int  min);
coord_t coordonnée_aléatoire(int x2, int y2);
void réinitialisation_ennemis(etat_t * e);
void reinitialisation_du_jeu(etat_t * e);
int detection_touches_esc_entrer(EtatSourisClavier esc);
void touches_début (etat_t * e, EtatSourisClavier esc);




int main() {
  creerTableau();
  fixerModeBufferisation(1);
  etat_t etat;
  etat = init_test();
  srand(time(NULL));
  while (etat.jeu_allumé && !fermetureDemandee() ) {
    affichage (etat);
    tamponner();
    effacerTableau();
    mise_a_jour(&etat);
  }
  return 0;
}




void affichage (etat_t etat) { 
  afficher_perso(etat.joueur);
  afficher_missile(etat);
  afficher_étoiles(etat);
  afficher_début_et_gameover(etat);
  afficher_coeur(etat);
  afficher_astéroide(etat);
  afficher_ennemis_et_missile (etat);      
  afficher_compteur(etat);
}

void afficher_ennemis_et_missile (etat_t etat) {
  for (int i =0;i<5;i++) {
    if (etat.ennemis[i].activé) { //affichage des ennemis actifs 
      afficherImage(etat.ennemis[i].image, etat.ennemis[i].position.x1-15, etat.ennemis[i].position.y2+5);
    }
    if (etat.ennemis[i].peu_tirer) { //affichage de leur missiles s'il peuvent tirer 
      for (int k=0;k<20;k++) {
	if (etat.ennemis[i].missile[k].boom) {	       
	  afficherImage(etat.ennemis[i].missile[k].image,etat.ennemis[i].missile[k].position.x1-5,etat.ennemis[i].missile[k].position.y2+10);
	}
      }
    }  //pour l'animation, on passe d'une image à l'autre selon num  
    if (etat.ennemis[i].explosion.activé) { 
      if (etat.ennemis[i].explosion.num==1) {
	afficherImage(etat.ennemis[i].explosion.image1, etat.ennemis[i].explosion.position.x1,etat.ennemis[i].explosion.position.y2);
      }
      if (etat.ennemis[i].explosion.num ==2){
	afficherImage(etat.ennemis[i].explosion.image2, etat.ennemis[i].explosion.position.x1-4,etat.ennemis[i].explosion.position.y2+6);}
    }
  }
}

void afficher_astéroide(etat_t etat) {
  for (int i=0; i<4; i++) {
    if (etat.astéroide[i].activé) {
      afficherImage(etat.astéroide[i].image,etat.astéroide[i].position.x1-10,etat.astéroide[i].position.y2+10);
    }  
    if (etat.astéroide[i].explosion.activé) {
      if (etat.astéroide[i].explosion.num==1) {
	afficherImage(etat.astéroide[i].explosion.image1, etat.astéroide[i].explosion.position.x1,etat.astéroide[i].explosion.position.y2);
      }   
      if (etat.astéroide[i].explosion.num ==2) {
	afficherImage(etat.astéroide[i].explosion.image2, etat.astéroide[i].explosion.position.x1-4,etat.astéroide[i].explosion.position.y2+6);
      }
    }
  }
}

void afficher_missile(etat_t etat){
  for (int i=0;i<20;++i) {
    if (etat.missile[i].boom==1) { //si le missile est actif(boom=1 , on l'affiche)
      afficherImage(etat.missile[i].image, etat.missile[i].position.x1-52,etat.missile[i].position.y2+7 );
    }
  }
}

void afficher_perso (perso joueur) {
  if (joueur.vie>0 && !joueur.explosion.activé) {
    if (!joueur.immunité || !joueur.immunité_clignotement) { //effet de clignotement car il disparait et réapparait semon immunité_clignotement
      afficherImage(joueur.image,joueur.position.x1,joueur.position.y2+27); }
  }
  if (joueur.explosion.activé) {
    if (joueur.explosion.num==1)
      {afficherImage(joueur.explosion.image1, joueur.explosion.position.x1, joueur.explosion.position.y2);  //affichage de l'explosion si vie==0
      }
    else if(joueur.explosion.num==2) {
      afficherImage(joueur.explosion.image2, joueur.explosion.position.x1, joueur.explosion.position.y2);
    }
  }
}

void afficher_étoiles (etat_t etat) {
  for (int j=0;j<40;j++) { //les étoiles sont des segments qui se coupent en leurs milieu
    choisirTypeStylo(1, etat.etoiles[j].couleur.r , etat.etoiles[j].couleur.r, etat.etoiles[j].couleur.r);
    tracerSegment(etat.etoiles[j].position.x1,etat.etoiles[j].position.y1,etat.etoiles[j].position.x1,etat.etoiles[j].position.y2);
    tracerSegment(etat.etoiles[j].position2.x1, etat.etoiles[j].position2.y1, etat.etoiles[j].position2.x2,etat.etoiles[j].position2.y1);
  }
}

void afficher_compteur(etat_t etat) {
  int x = 320, espacement = 60;
  if (etat.compteur.cpt ==0) {
    afficherImage(etat.compteur.image[0],x,280);
    etat.compteur.cpt =-1; //pour  sortir de la fonction s'il y a 0
  }
  while (etat.compteur.cpt>0) //while suffisament rapide pour qu'il n'y ait pas de bug visuel
    {
      int chiffre = etat.compteur.cpt % 10;   // affiche les chiffres un par un , en faisant reste de la division euclidienne par 10 
      afficherImage(etat.compteur.image[chiffre],x,280);
      etat.compteur.cpt = etat.compteur.cpt/10; //divise par 10 pour afficher le chiffre de l'unité suivante 
      x-=espacement; //pour chaque chiffre affiché, met un espace
    }
}

void afficher_début_et_gameover(etat_t etat) {
  if (etat.fin.activé) {
    afficherImage(etat.fin.image, etat.fin.position.x1,etat.fin.position.y2);
  }
  if (etat.début.activé) {
    afficherImage(etat.début.image, etat.début.position.x1,etat.début.position.y2);
  }
}

void afficher_coeur (etat_t etat)
{ int nbre_coeur = etat.joueur.vie/2, espace = 0,  nbre_demi = etat.joueur.vie%2; 
  for (int i = 0 ; i<nbre_coeur; i++) {
    if (!etat.joueur.immunité || !etat.joueur.immunité_clignotement) //les coeurs apparaissent et disparaissent quand le joueur n'est n'y immunisé ni quand immunitité clignotement est activé
      {
	afficherImage(etat.coeur.image[0],-350 + espace,280);
      }
    espace += 50;}
  if (nbre_demi!=0 && (!etat.fin.activé && !etat.joueur.immunité_clignotement) ) //nbre_demi est le reste de div euclidienne par 2 du nbre de coeur, s'il n'est pas pair, ils s'affichent 
    {  afficherImage(etat.coeur.image[1],-350+espace-9, 280+7); //y différent car légé décalage avec les coeurs plein
    }
}




etat_t init_test() { 
  etat_t e = {.joueur_mort = 0, .recharge = 0, .countdown_asté = 0, .countdown_ennemis = 0, .nbre_ennemis = 0, .groupe_ennemis = 0, .countdown_tir_ennemis = 0, .jeu_allumé =1, .manche=0};
  init_perso(&e);
  init_coeur(&e);
  init_image_début_et_fin (&e);
  init_étoiles(&e);
  init_image_explosion(&e);
  init_ennemis(&e);
  init_astéroide(&e);
  init_missile(&e);
  charger_image_compteur(&e);   
  init_son(&e);
  return e;
}

void init_son(etat_t * e) {
  e->tir_joueur = chargerAudio("sons/tir_joueur.wav");
  e->son_explosion = chargerAudio("sons/explosion.wav");
  e->son_explosion_astéroide = chargerAudio("sons/explosion_asté.wav");
  e->son_impact = chargerAudio("sons/impact.wav");
  e->son_impact_joueur = chargerAudio("sons/impact_joueur.wav");
  e->son_fin = chargerAudio("sons/son_fin.wav");
} 

void charger_image_compteur(etat_t * e) {
  e->compteur.image[0]=chargerImage("images/compteur/zero.png");
  e->compteur.image[1]=chargerImage("images/compteur/un.png");
  e->compteur.image[2]=chargerImage("images/compteur/deux.png");
  e->compteur.image[3]=chargerImage("images/compteur/trois.png");
  e->compteur.image[4]=chargerImage("images/compteur/quatre.png");
  e->compteur.image[5]=chargerImage("images/compteur/cinq.png");
  e->compteur.image[6]=chargerImage("images/compteur/six.png");
  e->compteur.image[7]=chargerImage("images/compteur/sept.png");
  e->compteur.image[8]=chargerImage("images/compteur/huit.png");
  e->compteur.image[9]=chargerImage("images/compteur/neuf.png");
  for (int i = 0 ; i<10;i++) {
    e->compteur.image[i] = rotozoomImage( e->compteur.image[i],  0.0,  0.5,  0.5 );
  } 
  e->compteur.cpt=0;
}

void init_missile(etat_t * e) {
  Image mi = chargerImage("images/Personnage_tir.png");
  for (int i=0;i<20;i++) {
    e->missile[i].boom=0; //missiles désactivés 
    e->missile[i].image = mi;   
  }
}

void init_astéroide(etat_t * e) {
  Image as= chargerImage("images/astéroide.png");
  for (int i = 0 ; i<4;i++)
    {
      e->astéroide[i].activé= 0;
      e->astéroide[i].image = as;
      e->astéroide[i].explosion.activé=0;
      e->astéroide[i].explosion.num=0;
    }
}

void init_ennemis(etat_t * e)
{ Image en = chargerImage("images/ennemis_1.png"), et = chargerImage("images/Ennemis_tir.png");
  e->ennemis1 = en;
  e->ennemis2 = chargerImage("images/ennemis_2.png");
  for (int i=0;i<5;i++)
    {
      e->ennemis[i].image=en;
      e->ennemis[i].activé = 0; 
      e->ennemis[i].recharge=0;
      e->ennemis[i].explosion.num=0;
      for (int k=0;k<20;k++)
	{
	  e->ennemis[i].missile[k].boom=0;
	  e->ennemis[i].missile[k].image= et;
	}
    }
}

void init_image_explosion(etat_t * e) {
  Image e1 =  chargerImage("images/Explosion_1.png"), e2 = chargerImage("images/Explosion_2.png");
  for (int i=0;i<5;i++) {
    e->ennemis[i].explosion.image1 = e1;
    e->ennemis[i].explosion.image2 = e2;
  }
  for (int i = 0 ; i<4;i++) {
    e->astéroide[i].explosion.image1 = e1;
    e->astéroide[i].explosion.image2 = e2;
  }
}

void init_étoiles(etat_t * e) {
  for (int j=0;j<40;j++) {
    e->etoiles[j].position.y1= rand() % (601) -300; //position sont les coordonées d'un point ou va débuter la droite
    e->etoiles[j].position.x1= rand() % (801) -300;
  
    e->etoiles[j].position.y2= (e->etoiles[j].position.y1>=0) ?   e->etoiles[j].position.y1-4 :e->etoiles[j].position.y1+4 ;
    e->etoiles[j].position2.y1= (e->etoiles[j].position.y1>=0) ? e->etoiles[j].position.y1-2:e->etoiles[j].position.y1+2 ;
    //position2 sont celles des points de la deuxième droite, ses coordonnées sont au dessus ou en dessous de l'autre selon y>0 ou y<0   
    e->etoiles[j].position2.x1=e->etoiles[j].position.x1-2;
    e->etoiles[j].position2.x2=e->etoiles[j].position.x1+2;
    int x = rand() % 3  + (-1);
    int couleur = (x>=0) ? 128 : 255 ;
    e->etoiles[j].couleur.r= couleur;
  }
}

void  init_perso (etat_t  * e) {
  e->image_joueur = chargerImage("images/Personnage.png");
  perso joueur ={ .position={.x1 = -500, .y1=20, .x2=-433, .y2=40}, .image=e->image_joueur, .vie = 6, .explosion.image1= chargerImage("images/Explosion_1.png"), .explosion.image2= chargerImage("images/Explosion_2.png"),.explosion.num=0,.immunité = 1, .dt_immunité=5.0, .immunité_clignotement=0};
  e->joueur = joueur;
}

void init_image_début_et_fin (etat_t * e) { 
  Image  e1=chargerImage("images/image_fin.png"),  e2  = chargerImage("images/image_début.png");
  e1= rotozoomImage(e1,0.0,600.0/tn_hauteur(e1),600.0/tn_hauteur(e1)); //image carrée donc on la dimensionne proportionnelement à la hauteur de l'écran
  e2 = rotozoomImage(e2,0.0,600.0/tn_hauteur(e2),600.0/tn_hauteur(e2));
  image_jeu image = {.image = e1,.position = { .x1=400, .y2=300}, .activé=0}, image2 = {.image = e2,.position = { .x1=-tn_largeur(e2)/2, .y2=300}, .activé=1};
  e->fin = image;
  e->début = image2;
  e->animation_debut =1; // animation au lancement
}

void init_coeur (etat_t * e) {
  Image e1 = chargerImage("images/coeur-plein.png"), e2 = chargerImage("images/demi-coeur.png");
  e1 = rotozoomImage( e1, 0.0, 0.7, 0.7);
  coeur_r c = {.image[0] = e1 , .image[1] = e2, .nbre_coeur = 3};
  e->coeur = c;
}




void mise_a_jour(etat_t * e) {
  EtatSourisClavier  esc =  lireEtatSourisClavier();
  double  dt= delta_temps();
  touches_début(e,esc);
  deplacement_étoiles(e->etoiles,dt,e);
  if (!e->début.activé) {
    mise_à_jour_joueur(e, esc, dt);
    apparition_astéroide(e,dt);
    apparition_missile(e,dt);
    collision_missile_astéroide(e);
    collision_joueur_ennemis(e);
    groupe_de_5_ennemis(e);
    champs_ennemis(e,dt);
    mise_à_jour_explosion( e,  dt);
    deplacement_et_collision_missile_ennemis(e);  
    e->countdown_ennemis -=dt; //mise à jour du temps d'apparition de chaque ennemis, à la fin
    touches_fin(e,esc);
  }
}




coord_t  coordonnée_aléatoire (int x2, int y2) /*donne des coordonnées aléatoires d'un objet allant de x1 à y2  */
{
  coord_t res = {.x1 = AXEX, .y1 = rand() % (AXEY-13 - (-AXEY+13) + 1 ) -AXEY+13 , .x2 = AXEX + x2 }; //Le champs d'apparition sur  y  haut-13 et bas+13 pour évitier que des objets apparaissent hors champs
  res.y2 = res.y1+y2;
  return res ;
}

void deplacement_vertical ( coord_t * e) /*déplcament vertical pour les ennemis */
{
  e->x1-=4;
  e->x2-=4;
}


int collision (coord_t objet, coord_t objet2)  /* collision entre deux objets*/
{
  if (objet.x1 >= objet2.x2 || objet.x2<=objet2.x1 || objet.y1>=objet2.y2 || objet.y2<=objet2.y1) {
    return 0;}
  return 1;
}

int  aléatoire(int  max, int  min) /* donne chiffres aléatoires PRIVE DE 0 */
{ int z=0;
  int n  = rand()% (2 - 1+1)+1; //On prend un nombre entre 1 et 2
  if (n==2) {
    z= rand()% (max - 1 +1) +1;} //si cest 2 on prend lintervalle 1 max
  else {
    z=rand()% (-1 -min +1) +min; //sinon intervalle -1 min
  }
  return z;
}

int hazard(int min, int max) {
  return rand()%(max - min +1)+min; //formule pour nbre aléatoire entre max et min avc 0
}

double norme (vecteur u) {
  return  sqrt((u.dx*u.dx)+(u.dy*u.dy)); //racine (x^2+y^2)
}

vecteur moyenne(coord_t a) {
  vecteur res  = {(a.x1+a.x2)/2 ,( a.y1+a.y2)/2}; //moyenne des deux points car les hitbox sont des rectangles, donc c'est mieux qu'ils visent au centre et pas à un coin
  return res;
}

vecteur vect(coord_t A, coord_t B) {
  vecteur a = moyenne(A);
  vecteur b = moyenne(B);
  vecteur v  = {.dx= a.dx-b.dx , .dy = a.dy-b.dy}; //vecteur directeur de A à B
  return v;
}

void animation_debut(etat_t * e) {
  if (e->animation_debut) //au départ le joueur est hors champs, puis on le déplace au debut champ
    { 
      if (e->joueur.position.x2<-313)
	{e->joueur.position.x1 += VITESSE_JOUEUR;
	  e->joueur.position.x2 += VITESSE_JOUEUR;
	}
      else{ e->animation_debut = 0; //désactive pr pas le refaire pendant le jeu
      }
    }
}

void deplacement_image_fin(image_jeu * fin, double dt) {
  if (fin->activé) {
    if  (fin->position.x1>-tn_largeur(fin->image)/2) //250 car x1 est a gauche, et le déplacement prend fin à 1/4 de l'écran
      {fin->position.x1-=120*dt; //meme vitesse que les étoiles
      }
  }
}

void mise_à_jour_joueur (etat_t * e, EtatSourisClavier esc, double dt)
{ animation_debut(e);
  if (!e->animation_debut) {  
    deplacement_joueur(&e->joueur,esc,dt);} // le joueur ne peut pas se déplacer pdnt animation
  mort_joueur(e);
  deplacement_image_fin(&e->fin,dt);
  deplacement_image_fin(&e->début,dt);
  if (e->joueur.immunité) {
    maj_immunité(&e->joueur,e,dt);
  }
}

void maj_immunité(perso * j,etat_t * e, double dt) {
  j->temps_clignotement+=dt;
  j->dt_immunité -=dt; //met à jour le temps d'immunité restant 
  if (j->dt_immunité<=0) {
    j->immunité = 0; //met à 0 immunité si le temps est écoulé 
    j->immunité_clignotement = 0;
    j->temps_clignotement = 0.0;
  }
  else {
    if (j->temps_clignotement>0.1)      //l'image apparait et disparait tte les 0.1s
      {j->immunité_clignotement = 1;
	j->temps_clignotement = 0.0;
      }
    else j->immunité_clignotement = 0;
  }
}

void activation_immunité(etat_t * e)
{if (e->joueur.immunité==0) {
    jouerSon(e->son_impact_joueur,0);
    if (e->joueur.vie>1) { //si le joueur n'est pas immunisé on peut enlever sa vie et activer son immunité 
      coord_t p =  {.x1=-380,.y1=20,.x2=-313,.y2=40};
      e->joueur.position = p;
    }
    e->joueur.vie-=1;
    e->joueur.immunité=1;
    e->joueur.dt_immunité=temps_immune;
  }
}

int detection_touches_esc_entrer(EtatSourisClavier esc)
{  int touches = 0; //touche = 1 si echap et 2 si entrée 
  for(int i=0;i<512;++i) {  
    if (esc.touchesClavier[41]==1) {
      touches = 1;
    }
    else if (esc.touchesClavier[40]) {
      touches = 2;
    }
  }
  return touches;
}

void touches_début (etat_t * e, EtatSourisClavier esc){
  int touche = detection_touches_esc_entrer(esc);
  if (touche == 2) {
    e->début.activé = 0; // si entrée l'image de fin disparait
  }
}
      
void touches_fin( etat_t * e,EtatSourisClavier esc){
  if (e->fin.position.x1< -250) {
    int touches = detection_touches_esc_entrer(esc);
    if (touches ==1) {
      e->jeu_allumé=0;} //le jeu se ferme si on appuie sur ECHAP
    else if (touches == 2) {
      reinitialisation_du_jeu(e); //si entrée on réinitialise le jeu
    }
  }
}

void reinitialisation_du_jeu(etat_t * e) {
  //remet tout à 0
  e->compteur.cpt = 0;
  e->fin.activé=0;
  e->joueur.vie=6; 
  e->joueur_mort=0;
  e->joueur.immunité = 1;
  e->joueur.dt_immunité = temps_immune;
  coord_t p =  {.x1=-500,.y1=20,.x2=-433,.y2=40};
  e->joueur.position = p;
  e->fin.position.x1=400;
  e->manche = 0;
  e->début.activé = 0 ;
  e->animation_debut = 1;
  réinitialisation_ennemis(e); 
}

void réinitialisation_ennemis(etat_t * e) {
  for (int i=0;i<5;i++)
    {if (e->ennemis[i].activé){
	e->ennemis[i].activé=0; //désactive ennemis 
	e->nbre_ennemis-=1;
	e->ennemis[i].explosion.position = e->ennemis[i].position;
	e->ennemis[i].explosion.activé = 1;
	e->ennemis[i].explosion.countdown=0.3;
      }
    }
}
		 
void mort_joueur (etat_t * e) {
  if (e->joueur.vie == 0 && !e->joueur.explosion.activé && e->joueur_mort ==0) //on veut faire une seule animation à sa mort, d'ou la condition sur joueur_mort (vie=0)
    {
      jouerSon(e->son_fin,0);
      e->joueur.explosion.position=e->joueur.position; 
      e->joueur.explosion.activé=1;
      e->joueur.explosion.countdown=0.3;
      e->joueur_mort = 1;  //le joueur est mort, affichage de son explosion
      e->fin.activé = 1; //active écran de fin		      
    }
}

void deplacement_joueur (perso * e, EtatSourisClavier esc, double dt) /*déplacement du joueur coté clavier*/
{if (esc.touchesClavier[7] == 1 && e->position.x2<=400 ) { 
      e->position.x1 += VITESSE_JOUEUR;
      e->position.x2 += VITESSE_JOUEUR;
    }
  if (esc.touchesClavier[4] == 1 && e->position.x1>=-400) {
      e->position.x1-=VITESSE_JOUEUR;
      e->position.x2-=VITESSE_JOUEUR;
    }
  if (esc.touchesClavier[26] == 1 && e->position.y2<=290) {
      e->position.y1 +=VITESSE_JOUEUR;
      e->position.y2 +=VITESSE_JOUEUR;
    }
  if (esc.touchesClavier[22] == 1 && e->position.y1>=-290) {
      e->position.y1 -=VITESSE_JOUEUR;
      e->position.y2 -=VITESSE_JOUEUR;
    }
}

void deplacement_étoiles(etoiles * etoiles, double dt, etat_t * e ) /*deplacement du fond, 40 étoiles sur le champs de vision*/
{
  for (int i=0;i<40;i++) {
    int vitesse = 75;
    if (e->joueur_mort){
      vitesse = 120;}
    if (etoiles[i].position.x1<=-AXEX ) {
      reinitialisation(&etoiles[i],e);}
    else {
      etoiles[i].position.x1-=vitesse*dt;
      etoiles[i].position2.x1-=vitesse*dt;
      etoiles[i].position2.x2-=vitesse*dt;
    }
  }
}

void reinitialisation (etoiles * e, etat_t * etat) /*remet à 0 les étoiles quand elles sortent du plan */
{
  e->position.y1=  rand() % (601) -AXEY; //hazard(-AXEY,AXEX) était faisable ici, mais il y a un écart de temps lorsqu'on appelle cette fonction qui rend le jeu moins beau, donc on applique la formule ici 
  e->position.x1= rand() % (450-AXEX+1) +AXEX;
  e->position.y2= (e->position.y1>=0) ?   e->position.y1-4 :e->position.y1+4 ;
  e->position2.y1= (e->position.y1>=0) ? e->position.y1-2:e->position.y1+2 ;
  e->position2.x1=e->position.x1-2;
  e->position2.x2=e->position.x1+2;
  if (etat->joueur_mort)
    disparition_étoiles(e);
  else {
    int x = rand() % 3  + (-1);
    int couleur = (x>=0) ? 128 : 255 ; //couleur entre le gris et le blanc
    e->couleur.r= couleur;
  }
}

void disparition_étoiles(etoiles * e) //la couleur des étoiles est noir comme le fond donc elles deviennent invisibles
{
  if (e->couleur.r>0)
    e->couleur.r=0;
}

void animation_explosion(image_explosion * explosion, double dt)
{ if (explosion->activé) // si explosion est actif, on affiche la premiere image pendant 0.15s puis la seconde pendant 0.3s
    { if (explosion->countdown>0) {
	if (explosion->countdown>0.15) {
	  explosion->num=1;
	}
	else if (explosion->countdown>0) {
	  explosion->num=2;}
      }
      else { explosion->num=0;      //si le delais d'affichage>0.3s, on retire désactive l'explosion
	explosion->activé=0;
      }
      explosion->countdown-=dt; //met à jour le temps d'explosion
    }
}


void mise_à_jour_explosion(etat_t * e, double dt)
{ for (int i=0;i<4;i++) {
    animation_explosion(&e->astéroide[i].explosion, dt); //applique la fonction animation_explosion à chaque astéroide, ennemis et au joueur
  }
  for (int j=0;j<5;j++) {
    animation_explosion(&e->ennemis[j].explosion, dt);
  }
  animation_explosion(&e->joueur.explosion, dt);
}

void apparition_astéroide( etat_t *  e, double dt) /* gère l'apparition des astéroides*/
{ for (int i = 0;i<4;i++) {
    int z = aléatoire(11,1); 
    if (z==7 && e->astéroide[i].activé==0 && e->countdown_asté<=0 && e->joueur.vie>0) /* les astéroides ont 1 chance sur 11 d'apparaitre*/
      {
	e->astéroide[i].activé = 1;
	e->astéroide[i].position = coordonnée_aléatoire(20,20); /*génère des coordonées aléatoires*/
	e->countdown_asté=10;
      }
  }
  for(int j=0;j<4;j++) {
    if (e->astéroide[j].activé){
      déplacement_astéroide(&e->astéroide[j], dt);  /*si l'astéroide est activé, on fait son déplacement)*/
      collision_joueur_astéroide(&e->joueur, &e->astéroide[j], e);   
    }
  }
  e->countdown_asté -=dt; //mise à jour de l'intervalle de temps d'appatition du prochain astéroide   
}

void déplacement_astéroide(astéroide * astéroide, double dt)
{ if(astéroide->position.x1<= -AXEX) /*cas ou l'astéroide sort du champ */
    {	astéroide->activé = 0;
    }
  else {
    astéroide->position.x1-=2; /*cas ou l'astéroide est dans le champ*/
    astéroide->position.x2-=2;
  }
}

void collision_joueur_astéroide(perso *  p, astéroide * astéroide, etat_t *  e) //désactive l'astéroide si collision et retire une vie 
{ if (collision(astéroide->position, p->position) && e->joueur.vie>0) {
    jouerSon(e->son_impact,0);
    astéroide->activé = 0; 
    astéroide->explosion.position=astéroide->position; //activation animation_explosion
    astéroide->explosion.activé=1;
    astéroide->explosion.countdown=0.3;
    activation_immunité(e);//enleve vie
  }
}
  
void apparition_missile (etat_t * e, double dt) //génère le missile quand on appuie sur espace, et si on dépasse pas la limite de temps
{ if (toucheEnfoncee(44) == 1 && e->recharge<=0 && e->joueur.vie>0 ) {
    jouerSon(e->tir_joueur, 0);
    e->recharge = 0.25;
    int k = recherche_missile_actif(e->missile);
    e->missile[k].boom=1;  //active le missile en question
    e->missile[k].position.x1=e->joueur.position.x2;
    e->missile[k].position.x2=e->joueur.position.x2+10;
    e->missile[k].position.y1=e->joueur.position.y1+7;
    e->missile[k].position.y2=e->joueur.position.y2-7;	
  }
  déplacement_missile(e->missile, dt);
  e->recharge -=dt;
}

int recherche_missile_actif (missile  missile[] ) 
{  int p=0;
  for (int j=0;j<20;j++) {
    if (missile[j].boom==0) {
      p=j;
      break; //boucle s'arrete quand un missile n'est pas acitvé 
			  
    }
  }
  return p;
}

void déplacement_missile( missile * missile, double dt) //gere le déplacement des missiles
{ for (int i=0;i<20;i++)  {
    if(missile[i].boom==1) {
      if (missile[i].position.x1>=350 && missile[i].position.x2>=350) {
	missile[i].boom=0;    //si le missile sort, il est désactivé
      }
      else {
	missile[i].position.x1+=25; //déplacement des missiles a une vitesse 
	missile[i].position.x2+=25;
      }
    }
  }
}

void collision_missile_astéroide(etat_t * e)  //collision missile/astéroide 
{for (int j=0;j<20;j++) {
    if (e->missile[j].boom==1) //recherche missiles actiifs
      {for (int k=0;k<4;k++) {
	  if (e->astéroide[k].activé && e->joueur.vie>0){
	   
	    if (collision(e->missile[j].position,e->astéroide[k].position)) //si il y a collision, on désactive
	      { jouerSon(e->son_explosion_astéroide,0);
		e->astéroide[k].activé = 0;
		e->missile[j].boom = 0 ;
		e->astéroide[k].explosion.position=e->astéroide[k].position;
		e->astéroide[k].explosion.activé=1;
		e->astéroide[k].explosion.countdown=0.3;
		  
	      }
		
	  }
	}	 
	collision_missile_ennemis (e,&e->missile[j]);
	  
      }
  }
}

void collision_missile_ennemis (etat_t * e, missile * missile) //collision des missiles du joueur sur les ennemis
{
  for(int k=0;k<5;k++) {
    if (e->ennemis[k].activé){
      if (collision(missile->position,e->ennemis[k].position))    //désactive l'ennemis si il y a collision entre le missile du joueur et de l'ennemi
	{ jouerSon(e->son_explosion,0);
	  e->ennemis[k].activé = 0;
	  e->nbre_ennemis-=1;
	  missile->boom=0;
	  e->ennemis[k].explosion.position=e->ennemis[k].position;
	  e->ennemis[k].explosion.activé=1;
	  e->ennemis[k].explosion.countdown=0.3; 
	  if (e->ennemis[k].peu_tirer) { //+5 si ennemis tire , +1 
	    e->compteur.cpt+=5;}
	  else e->compteur.cpt+=1;
	}
    }
  }
}
    
void collision_joueur_ennemis (etat_t * e) //gère la collision_joeur_ennemis
{
  for (int i=0;i<5;i++) {
    if (e->ennemis[i].activé) {
      if (collision(e->ennemis[i].position, e->joueur.position) && e->joueur.vie>0) //réninitialise la case du tableau de l'ennemi concerné 
	{ jouerSon(e->son_impact,0);
	  activation_immunité(e);//enleve vie
	  e->ennemis[i].activé=0; //désactive ennemis 
	  e->nbre_ennemis-=1;
	  e->ennemis[i].explosion.position = e->ennemis[i].position;
	  e->ennemis[i].explosion.activé = 1;
	  e->ennemis[i].explosion.countdown=0.3;
	}
    }
  }
}


void groupe_de_5_ennemis(etat_t * e) //génère un groupe de 5 ennemis
{
  if (e->groupe_ennemis==0 && e->countdown_ennemis<=0  && e->joueur.vie>0)  //vériie s'il n'y a pas déjà un groupe, que le cooldown est respecté et que le perso est en vie
    {  
      for (int k=0;k<5;k++) {
	if (e->countdown_ennemis <= 0 && e->ennemis[k].activé==0 ) 
	  { int z = hazard(1,6-e->manche);
	    //probabilité qu'un ennemis puisse tirer ou non (augmente on fonction de la manche)
	    if ( z ==1)
	      {
		e->ennemis[k].peu_tirer = 1;
		e->ennemis[k].image = e->ennemis1;}
	    else {
	      e->ennemis[k].peu_tirer = 0;
	      e->ennemis[k].image= e->ennemis2;
	    }
	    e->ennemis[k].position=coordonnée_aléatoire(35,35);
	    e->ennemis[k].sens= aléatoire(1,-1); //leur sens est aléatoire 
	    e->nbre_ennemis+=1;
	    e->ennemis[k].activé=1;
	    e->countdown_ennemis = 2;
	  }
      }
    }
}


void champs_ennemis(etat_t * e, double dt)  //on désactive les ennemis hors champs 
{
  if (e->nbre_ennemis != 0) {
    ecart_temps_ennemis(e);
    liste_ennemis_capables(e,dt); //on liste tout les ennemis capables de tirer
    for (int j = 0; j < 5; j++) {
      if (e->ennemis[j].activé) { //désactive ennemis hors champs
	if (e->ennemis[j].position.x1 <= -AXEX) {
	  e->ennemis[j].activé = 0;
	  e->nbre_ennemis -= 1;
	} else { 
	  sens_déplacement_ennemis(&e->ennemis[j]);
	}
      }
    }
  } else {
    e->groupe_ennemis = 0; //grpe ennemie passe à 0 s'il n'y en a plus (manche suivante, maximum 4)
    if ( e->manche<4) e->manche +=1;
  }    
}

void liste_ennemis_capables (etat_t * e, double dt) /*gère le tir aléatoire des ennemis*/ { 
  int l[5], n=0;
  for (int j =0 ;j<5;j++) // on met dans une liste l'indice des ennemis qui peuvent tirer
    {
      if (e->ennemis[j].activé && e->ennemis[j].peu_tirer && (e->ennemis[j].position.x1>e->joueur.position.x2)) //si actif et peu tirer ET qu'il n'est pas derrière le vaisseau
	{l[n] = j;
	  n+=1;
	}
    }
  e->countdown_tir_ennemis-=dt; 
  if (e->countdown_tir_ennemis <= 0 && n > 0) {
    int k = hazard(0,n-1); //on choisi au hazar un ennemis dans cette liste, entre 0 et n, dernier indice possible puis on le fait tirer
    tir_ennemis(&e->ennemis[l[k]], &e->joueur);
    e->countdown_tir_ennemis = 1.5; 
  }
}

void tir_ennemis (ennemis * ennemis, perso * joueur) //gère le déplacement des missiles ennemis 
{if (joueur->vie>0) {     
      ennemis->recharge = 0.25; //ils ne peuvent plus tirer pendant 25s
      int p =  recherche_missile_actif (ennemis->missile);
      ennemis->missile[p].boom=1; //active le missile
      ennemis->missile[p].position.x1=ennemis->position.x1; //position d'apparation des missiles (=celle du tireur)
      ennemis->missile[p].position.x2=ennemis->position.x2;
      ennemis->missile[p].position.y1=ennemis->position.y1;
      ennemis->missile[p].position.y2=ennemis->position.y2;
      vecteur A = vect(joueur->position,ennemis->position); //vecteur directeur entre position du joueur et celle de l'ennemi
      double z = norme(A);
      if (z==0){ //pour eviter une division par 0
	z=1;}
      double v =12;
      ennemis->missile[p].v.dx = (A.dx/z)*v;
      ennemis->missile[p].v.dy = (A.dy/z)*v;
    }
}
		     

void ecart_temps_ennemis(etat_t * e) //s'il y plus de 5 ennemis, un groupe est formé et le suivant n'apparait qu'après 12s - la manche
{
  if (e->nbre_ennemis==5)
    {e->groupe_ennemis =1;
      e->countdown_ennemis=12-e->manche;
    }
}

void sens_déplacement_ennemis(ennemis *  ennemis) //on défini ici le sens de déplacement des ennemis (diagonale)
{ if (ennemis->position.y2<=-285)      //si on touche un bord on va dans le sens opposé                     
    {ennemis->sens=ennemis->sens*(-1);
    }
  if (ennemis->position.y1>=285) {
    ennemis->sens=ennemis->sens*(-1);
  }
  if (ennemis->sens <0) //se déplace en diagonale de haut en bas et inversement selon son sens
    {		  
      ennemis->position.x1+=ennemis->sens;
      ennemis->position.x2+=ennemis->sens;
      ennemis->position.y1+=ennemis->sens;
      ennemis->position.y2+=ennemis->sens;
    }
  else {        
    ennemis->position.x1-=ennemis->sens;
    ennemis->position.x2-=ennemis->sens;
    ennemis->position.y1+=ennemis->sens;
    ennemis->position.y2+=ennemis->sens;
  }		  		  
}

void deplacement_et_collision_missile_ennemis(etat_t * e ) {
  for (int k=0;k<5;k++) {
    for (int i=0;i<20;i++)
      { if (e->ennemis[k].missile[i].boom == 1 ){ //on verifie d'abord si le missile est actif pour éviter de perdre de la vie avant 
	  if (collision(e->ennemis[k].missile[i].position,e->joueur.position))
	    {activation_immunité(e);
	      e->ennemis[k].missile[i].boom=0;
	    }
	  //si le missile sort du plan on le désactive
	  if (e->ennemis[k].missile[i].position.x1<=-350 && e->ennemis[k].missile[i].position.x2<=-350)  {
	    e->ennemis[k].missile[i].boom=0;
	  }
	  else { //sinon il se déplace (selon le vecteur directeur)   
	    e->ennemis[k].missile[i].position.x1+=e->ennemis[k].missile[i].v.dx;
	    e->ennemis[k].missile[i].position.x2+=e->ennemis[k].missile[i].v.dx;
	    e->ennemis[k].missile[i].position.y1+=e->ennemis[k].missile[i].v.dy;
	    e->ennemis[k].missile[i].position.y2+=e->ennemis[k].missile[i].v.dy;
	  }
	}
      }
  }
}
