function getResponse() {
	var input = document.getElementById("input").value;
	var output = document.getElementById("output");
	var response = generateResponse(input);
	output.innerHTML += "<p><strong>Vous:</strong> " + input + "</p>";
	output.innerHTML += "<p><strong>Chatbot:</strong> " + response + "</p>";
	document.getElementById("input").value = "";
	output.scrollTop = output.scrollHeight;
	return false;
}

function generateResponse(input) {
	var output = "";
	input = input.toLowerCase();
	if (input.indexOf("bonjour") !== -1 || input.indexOf("salut") !== -1 || input.indexOf("hello") !== -1) {
		output = "Bonjour ! Comment ça va ?";
	} else if (input.indexOf("comment ça va") !== -1) {
		output = "Je suis un chatbot, je ne peux pas vraiment ressentir quoi que ce soit, mais je suis là pour discuter avec vous ! Et vous, comment ça va ?";
	} else if (input.indexOf("merci") !== -1 || input.indexOf("c'est gentil") !== -1) {
		output = "De rien, c'est normal !";
	} else if (input.indexOf("quelle est la réponse à la vie, l'univers et tout le reste") !== -1) {
		output = "42.";
  
  } else if (input.indexOf("as-tu une série à me proposer ?") !== -1) {
		output = "En tant que chatbot, je ne peux vous en conseiller, mais Sasmithan vous conseile de regarder la casa del papel";
  } else if (input.indexOf("quand se terminent les vacances d'avril?") !== -1) {
		output = "Les vacances scolaires du mois d'avril prennent fin le 01/05/23";
  } else if (input.indexOf("ça va et toi ?") !== -1) {
		output = "ça va merci ! Comment puis-je vous aider ?";
  } else if (input.indexOf("Quand as tu été conçu ?") !== -1) {
		output = "*J'ai été conçu le 21/04/2023";
	} else if (input.indexOf("quelle est ta couleur préférée") !== -1) {
		output = "Je suis un chatbot, je ne peux pas voir les couleurs !";
	} else {
		output = "Je suis désolé, je ne comprends pas. Pouvez-vous reformuler votre question ?";
	}
	return output;
}
