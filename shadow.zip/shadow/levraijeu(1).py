import pygame
from time import time
from pygame.locals import *

class Projectile(pygame.sprite.Sprite):
    def __init__(self, x, y, cible):
        super().__init__()
        self.vel = 5
        self.image = pygame.image.load("fireball.png")
        self.image = pygame.transform.scale(self.image, (50, 50))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.image_origine = self.image
        self.angle = 0
        self.cible = cible


    def update(self):
        self.rotate()
        self.rect.x -= self.vel
        if self.rect.x > 800:
            self.kill()


        if pygame.sprite.collide_rect(self, self.cible):
            if self.cible.rect.y<220:
                self.cible.vie-=0
                self.kill()
            if self.cible.rect.y==200:
                self.cible.vie -= 50
                self.kill()

    def rotate(self):
        self.angle += 12
        self.image = pygame.transform.rotozoom(self.image_origine, self.angle, 1)
        self.rect = self.image.get_rect(center=self.rect.center)

class Personnage1(pygame.sprite.Sprite):
    def __init__(self, touches, images_marche, image_saute, images_attaque, position, p):
        super().__init__()
        self.touches = touches
        self.image_normale = pygame.image.load('avance2.png')
        self.image_normale = pygame.transform.scale(self.image_normale, (150, 200))
        self.image = self.image_normale

        self.images_marche = [pygame.transform.scale(img, (220, 250)) for img in images_marche]
        self.image_saute = pygame.transform.scale(image_saute, (200, 230))
        self.images_attaque = images_attaque

        self.image_marche_index = 0
        self.isjump = False
        self.v = 8
        self.m = 1
        self.rect = self.image.get_rect()
        self.rect.x, self.rect.y = position

        self.vie = 1200
        self.isattaque = False
        self.p = p
        self.all_projectiles = pygame.sprite.Group()

    def lancer_projectile(self, cible):


            projectile = Projectile(self.rect.x + self.rect.width // 2, self.rect.y + self.rect.height // 2, cible)
            self.all_projectiles.add(projectile)

    def booléen(self):
        global temps
        if time() - temps > 0.25 and self.isattaque:
            temps = time()
            self.image = self.images_attaque[0]
            self.isattaque = False
            return True
        if time() - temps > 0.5 and not self.isattaque:
            key_pressed_is = pygame.key.get_pressed()
            if key_pressed_is[self.touches[3]]:
                self.isattaque = True
        return False

    def jump(self):
        if not self.isjump:
            key_pressed_is = pygame.key.get_pressed()
            if key_pressed_is[self.touches[2]]:
                self.isjump = True
                self.v = 8
                self.m = 1

        if self.isjump:
            self.image = self.image_saute
            F = (1 / 2) * self.m * (self.v ** 2)
            self.rect.y -= F
            self.v = self.v - 1

            if self.v < 0:
                self.m = -1

            if self.v == -9:
                self.isjump = False
                self.v = 8
                self.m = 1
                self.rect.y = max(self.rect.y, 200)
                self.image = self.image_normale

    def move(self):
        key_pressed_is = pygame.key.get_pressed()
        if key_pressed_is[self.touches[0]] and self.rect.x > 0:
            self.rect.x -= 4
            self.update_walk_animation()
        if key_pressed_is[self.touches[1]] and self.rect.x < 550:
            self.rect.x += 4
            self.update_walk_animation()

    def update_walk_animation(self):
        if not self.isjump:
            if self.image_marche_index >= len(self.images_marche) - 1:
                self.image_marche_index = 0
            else:
                self.image_marche_index += 1
            self.image = self.images_marche[self.image_marche_index]

    def get_image(self):
        key_pressed_is = pygame.key.get_pressed()
        if key_pressed_is[self.touches[3]] and self.images_attaque:
            return self.images_attaque[0]
        if not self.isjump and not self.isattaque:
            return self.images_marche[self.image_marche_index]
        if self.isjump:
            return self.image_saute
        return self.image_normale

    def get_position(self):
        return self.rect.x, self.rect.y

    def affichage(self):
        label = myfont.render(str(self.vie), 1, (255, 0, 0))
        g1 = myfont.render("Victoire du joueur1!", True, (0, 0, 0))
        g2 = myfont.render("Victoire du joueur2!", True, (0, 0, 0))
        if self.p == "droit":
            windowSurface.blit(label, (650, 20))
        elif self.p == 'gauche':
            windowSurface.blit(label, (100, 20))
        if perso1.vie == 0:
            windowSurface.blit(g2, (300, 20))
        if perso2.vie == 0:
            windowSurface.blit(g1, (300, 20))

    def recommencer(self):
        key_pressed_is = pygame.key.get_pressed()
        if key_pressed_is[pygame.K_4]:
            self.vie=1200
            perso1.rect.x=350
            perso1.rect.y=200
            perso2.rect.x=50
            perso2.rect.y=200

class Attaque:
    def __init__(self, personnage1, personnage2):
        self.perso1 = personnage1
        self.perso2 = personnage2

    def attaque_basique(self):
        if self.perso1.booléen() and self.perso2.vie > 0:
            if self.perso2.rect.x < self.perso1.rect.x:
                if self.perso2.rect.x + 120 > self.perso1.rect.x:
                    self.perso2.vie -= 100
            if self.perso2.rect.x > self.perso1.rect.x:
                if self.perso2.rect.x < self.perso1.rect.x + 120:
                    self.perso2.vie -= 100
        if self.perso2.booléen() and self.perso1.vie > 0:
            if self.perso1.rect.x < self.perso2.rect.x:
                if self.perso1.rect.x + 120 > self.perso2.rect.x:
                    self.perso1.vie -= 100
            if self.perso1.rect.x > self.perso2.rect.x:
                if self.perso1.rect.x < self.perso2.rect.x + 190:
                    self.perso1.vie -= 100
                    self.perso1.rect.x += 50







pygame.init()
screen = pygame.display.set_mode((800, 500))
clock = pygame.time.Clock()
fond = pygame.image.load('fond1.jpg')
fond = pygame.transform.scale(fond, (800, 500))

touchej1 = [pygame.K_LEFT, pygame.K_RIGHT, pygame.K_KP0, pygame.K_KP1, pygame.K_4]
touchej2 = [pygame.K_a, pygame.K_d, pygame.K_SPACE, pygame.K_3]
perso1 = Personnage1(touchej1, [
    pygame.image.load('avance2.png'),
    pygame.image.load('avance2.png'),
    pygame.image.load('avance2.png'),
    pygame.image.load('avance2.png'),
    pygame.image.load('avance2.png'),
    pygame.image.load('avance3.png'),
    pygame.image.load('avance3.png'),
    pygame.image.load('avance3.png'),
    pygame.image.load('avance3.png'),
    pygame.image.load('avance4.png'),
    pygame.image.load('avance4.png'),
    pygame.image.load('avance4.png'),
    pygame.image.load('avance3.png'),
    pygame.image.load('avance4.png')], pygame.image.load("personnage1_a.png"),
    [pygame.image.load("p1_attaque1.0.png"),
     pygame.image.load("p1_attaque1.1.png"),
     pygame.image.load("p1_attaque1.2.png"),
     pygame.image.load("p1_attaque1.3.png")], (350, 200), "droit")



perso2 = Personnage1(touchej2, [
    pygame.image.load('perso2_a1.png'),
    pygame.image.load('perso2_a3.png'),
    pygame.image.load('perso2_a3.png'),
    pygame.image.load('perso2_a3.png'),
    pygame.image.load('perso2_a3.png'),
    pygame.image.load('perso2_a1.png'),
    pygame.image.load('perso2_a1.png'),
    pygame.image.load('perso2_a1.png'),
    pygame.image.load('perso2_a1.png'),
    pygame.image.load('perso2_a3.png')], pygame.image.load("perso2_s2.png"),
    [pygame.image.load("p2_attaque1.0.png")], (50, 200), "gauche")


liste_joueur = [perso1, perso2]

run = True

windowSurface = pygame.display.set_mode((800, 500))
myfont = pygame.font.SysFont("monospace", 15)
temps = time()
attaque_perso = Attaque(perso1, perso2)


while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

        elif event.type == pygame.KEYDOWN:
            if event.type==pygame.K_4:
                start()
            if event.key == pygame.K_y:
                perso1.lancer_projectile(perso2)
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_y:
                pass

    screen.blit(fond, (0, 0))

    for joueur in liste_joueur:
        joueur.move()
        joueur.jump()
        joueur.affichage()
        joueur.recommencer()
        for j in joueur.all_projectiles:
            j.update()

        joueur.all_projectiles.draw(screen)
        screen.blit(joueur.get_image(), joueur.get_position())


        joueur.all_projectiles.draw(screen)
        screen.blit(joueur.get_image(), joueur.get_position())


    key_pressed_is = pygame.key.get_pressed()



    if perso2.rect.x < perso1.rect.x:
        if perso2.rect.x > perso1.rect.x - 50:
            if not key_pressed_is[touchej2[1]]:
                perso2.rect.x = perso1.rect.x - 50
            if not key_pressed_is[touchej1[0]]:
                perso1.rect.x = perso2.rect.x + 50
            if key_pressed_is[touchej2[2]] and key_pressed_is[touchej2[1]]:
                perso2.rect.x = perso1.rect.x + 50
            if key_pressed_is[touchej1[2]] and key_pressed_is[touchej1[0]]:
                perso1.rect.x = perso2.rect.x - 50
            else:
                perso1.rect.x += 4
                perso2.rect.x -= 4

    if perso2.rect.x > perso1.rect.x:
        if perso2.rect.x - 50 < perso1.rect.x:
            if not key_pressed_is[touchej2[0]]:
                perso2.rect.x = perso1.rect.x + 50
            if not key_pressed_is[touchej1[1]]:
                perso1.rect.x = perso2.rect.x - 50
            if key_pressed_is[touchej2[2]] and key_pressed_is[touchej2[0]]:
                perso2.rect.x = perso1.rect.x - 50
            if key_pressed_is[touchej1[2]] and key_pressed_is[touchej1[1]]:
                perso1.rect.x = perso2.rect.x + 50
            else:
                perso1.rect.x -= 4
                perso2.rect.x += 4


    attaque_perso.attaque_basique()

    pygame.display.flip()
    clock.tick(30)

pygame.quit()
