#ifndef __EXERCICE3__
#define __EXERCICE3__

#include "API_Grille.h"
#include "Liste_case.h"


int occurence_couleur_bordure (S_Zsg *S, int occ[]);
int max_bordure(int **M, Grille *G, int dim, int nbcl, int aff);

#endif