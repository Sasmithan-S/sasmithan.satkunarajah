// Récupérer les éléments HTML
const target = document.getElementById("target");
const score = document.getElementById("score");
const timer = document.getElementById("timer");

// Initialiser les variables du jeu
let scoreCount = 0;
let timeLeft = 10;

// Fonction pour mettre à jour le score
function updateScore() {
	scoreCount++;
	score.innerText = scoreCount;
}

// Fonction pour mettre à jour le temps restant
function updateTimer() {
	if (timeLeft > 0) {
		timeLeft--;
		timer.innerText = timeLeft;
	} else {
		// Si le temps est écoulé, arrêter le jeu et afficher le score final
		clearInterval(timerInterval);
		target.removeEventListener("click", handleTargetClick);
		alert("Temps écoulé ! Votre score est de " + scoreCount + ".");
	}
}

// Fonction pour gérer le clic sur la cible
function handleTargetClick() {
	updateScore(); // Mettre à jour le score
	updateTargetPosition(); // Changer la position de la cible
}

// Fonction pour changer la position de la cible
function updateTargetPosition() {
	const maxX = 450; // La valeur maximale de la position X
	const maxY = 450; // La valeur maximale de la position Y
	const newX = Math.floor(Math.random() * maxX); // Obtenir une nouvelle position X aléatoire
	const newY = Math.floor(Math.random() * maxY); // Obtenir une nouvelle position Y aléatoire
	target.style.left = newX + "px"; // Changer la position X de la cible
	target.style.top = newY + "px"; // Changer la position Y de la cible
}

// Ajouter un écouteur d'événement pour le clic sur la cible
target.addEventListener("click", handleTargetClick);

// Lancer le jeu
updateTargetPosition(); // Changer la position initiale de la cible
const timerInterval = setInterval(updateTimer, 1000); // Mettre à jour le temps restant toutes les secondes

